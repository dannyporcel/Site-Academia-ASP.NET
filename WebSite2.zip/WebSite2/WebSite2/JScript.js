﻿function verif() {

    alert('lalalalalal')

}